package utilities;


import java.io.FileWriter;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

public final class GreatMagician implements Observer {
    private final FileWriter fileWriter;

    public GreatMagician(final FileWriter fileWriter) {
        this.fileWriter = fileWriter;
    }

    @Override
    public void update(final Observable o, final Object arg) {
        try {
            fileWriter.write(arg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
