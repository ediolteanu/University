package game;

public enum TerrainType { Land, Volcanic, Desert, Woods }
